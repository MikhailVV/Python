
import sys
for i, p in enumerate(sys.argv):
    print (f'{i} --> {p}')
